import json
import re
import time
import string
from urllib2 import urlopen
from pprint import pprint
from Tkinter import *
import datetime
from subprocess import Popen
import subprocess
import webbrowser


#get data from API gateway based on topicname

path=['GLM','Other']
a=0
while a < len(path):
    websource = urlopen('https://kfwu29hvm3.execute-api.us-west-2.amazonaws.com/Dynamo_to_API_Gateway/topic/'+path[a])
    data = json.loads(websource.read().decode())
    #pprint(data)

    #position designator in Items list
    x=0
    TStable=[]
    TOPICtable=[]
    PAYLOADtable=[]
    while (x < len(data['Items'])):
        #specific position selector
        timestamp=data['Items'][x]['Timestamp']
        topic=data['Items'][x]['Topic']
        payload=data['Items'][x]['payload']
        #removal of unwanted characters from data set
        ts=str(timestamp).translate(None, "{u'S':}")
        topicstr=str(topic).translate(None, "{u'S': }")
        payloadstr=str(payload).translate(None, "{u'S':}")
        ts2=int(ts)
        TStable.append(ts2)
        TOPICtable.append(topicstr)
        PAYLOADtable.append(payloadstr)
        x=x+1


    #variable creations based on topic
    vars()["Status"+str(a)]=[]
    #latest update selection
    z=TStable.index(max(TStable))
 
    vars()["Status"+str(a)].append(str(TStable[z]))
    vars()["Status"+str(a)].append(TOPICtable[z])
    vars()["Status"+str(a)].append(PAYLOADtable[z])    
    #print(str(vars()["Status"+str(a)]))
    a=a+1
    
#print(Status0)
#print(Status1)


root = Tk()
root.title("Grass Level Monitor V1.0")
root.state('zoomed')
top = Frame(root)
top.pack()
bot = Frame(root)
bot.pack(side=BOTTOM, pady=50)

label1 = Label(top, text="GRASS LEVEL MONITOR", bg="Green", relief=RIDGE, padx=8,pady=10,borderwidth=5)
label2 = Label(top, text="Last Refresh: "+time.strftime("%c"), fg="blue", pady=10)
#label2 = Label(top, text="Last Refresh: "+time.strftime("%B %d, %Y  %I:%m:%S %p"), fg="blue", pady=10)

def refresh():
    root.destroy()
    subprocess.Popen("Grass Level Monitor.exe")

url = 'https://us-west-2.console.aws.amazon.com/sns'

def OpenUrl(url):
    webbrowser.open_new(url)

refresh = Button(top, text="Refresh Window", command=refresh, bg="black", fg="white")
Update = Button(top, text="Tigger Updates", command=lambda aurl=url:OpenUrl(aurl), bg="black", fg="white")

label3 = Label(top, text="DeviceID", fg="red", padx=15, pady=10)
label4 = Label(top, text="Location", fg="red", padx=15, pady=10)
label5 = Label(top, text="Last Update", fg="red", padx=15, pady=10)
label6 = Label(top, text="Status", fg="red", padx=15, pady=10)
label7 = Label(bot, text="International College of Auckland  |  Department of Electrical Engineering")
label8 = Label(bot, text="GLM Version 1.0")

label1.grid(row=0, columnspan=4, sticky=E+W)
label2.grid(row=1, columnspan=4)
refresh.grid(row=2,column=1)
Update.grid(row=2, column=2)
label3.grid(row=3, column=0)
label4.grid(row=3, column=1)
label5.grid(row=3, column=2)
label6.grid(row=3, column=3)
label7.grid(row=0)
label8.grid(row=1)

b=0
while b < len(path):
    timeConvert=int((vars()["Status"+str(b)])[0])/1000
    #print(int((vars()["Status"+str(b)])[0]))
    convertedTime=datetime.datetime.fromtimestamp(timeConvert).strftime('%c')
    if "GLM" in (vars()["Status"+str(b)])[1]:
        c="CityCentre"
        d="131 Queen St. CBD Auckland"
    else:
        if "Other" in (vars()["Status"+str(b)])[1]:
            c="Mt. Eden"
            d="131 Queen Street Auckland"
        else:
            print ("Error")

    if "M Message  The grass is still short." in (vars()["Status"+str(b)])[2]:
        e="The grass is still short."
    else:
        e="Ready for mowing."
        
    label7 = Label(top, text=c, padx=15)
    label8 = Label(top, text=d, padx=15)
    label9 = Label(top,text=convertedTime, padx=15)
    label10 = Label (top, text=e, padx=15)

    label7.grid(row=4+b, column=0)
    label8.grid(row=4+b, column=1)
    label9.grid(row=4+b, column=2)
    label10.grid(row=4+b, column=3)
    b=b+1


root.mainloop()
