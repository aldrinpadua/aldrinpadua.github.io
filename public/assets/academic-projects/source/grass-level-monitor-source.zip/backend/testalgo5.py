#from __future__ import division
import PIL
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
import time
from time import sleep
#from picamera import PiCamera

'''camera=PiCamera()
#camera.rotation=90
camera.resolution = (500, 500)
camera.capture('ar.png')
sleep(5)'''

def threshold(imageArray):
    balanceAr=[]
    newAr=imageArray

    #define color sensitivity here:    
    for eachRow in newAr:
        for eachPix in eachRow:
            if eachPix[0]<=105 and eachPix[1]<=255 and eachPix[2]<=105:
                eachPix[0]=255
                eachPix[1]=255
                eachPix[2]=255
                eachPix[3]=255
            else:
                eachPix[0]=0
                eachPix[1]=0
                eachPix[2]=0
                eachPix[3]=255       
    return newAr
          
a="The grass is now ready for mowing."
b="The grass is still short."
i = Image.open('tallgrass.jpeg')
iar = np.array(i)
#print(iar)

threshold(iar)

#print (iar)
fig=plt.figure()
#plot1=plt.subplot2grid((20,20),(0,0),rowspan=4, colspan=3)

plt.imshow(iar)
plt.imsave("newAr.png",iar,format="png")
#plt.show()

converted=Image.open('newAr.png')
converted2=np.array(converted)
#print (converted2)

def averaging(picToAve):
    balance2=[]
    aveRow=[]
    currentPic=picToAve
    for eachRow2 in currentPic:
        for eachPix2 in eachRow2:
            avePix=sum(eachPix2[:3])/len(eachPix2[:3])
            balance2.append(avePix)
                
    x=0
    y=len(eachRow2)
    while(y <= (len(eachRow2)*len(currentPic))):
        aveRow.append(sum(balance2[x:y])/len(eachRow2))
        x=y
        y=x+len(eachRow2)

    #print(aveRow)

    #define threshold here    
    if aveRow[140]>=153:
        z= a
        print(z)

    else:
        z= b
        print(z)
               
    return z 

p=averaging(converted2)
print (p)

'''fig2=plt.figure()
plt.imshow(converted2)
plt.imsave("newAr2.png",converted2,format="png")
plt.show()'''
         
         

         


