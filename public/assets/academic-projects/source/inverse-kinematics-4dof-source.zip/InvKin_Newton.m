function [qf, iter, abs_err] = InvKin_Newton(P, q_guess, a,tol)
%INVKIN_NEWTON Inverse Kinematics of 4-DoF 4-Revolute Robotic Arm
%   Computes for the configuration of the revolute joints given the final 
%   position of the arm's end point via Newton's Method.
%   Input:
%       P   = vector containing the coordinates [x y z] of the arm's
%            desired end-point position
%       q_guess = initial guess for the joint variable values, thetas, in
%            in degrees 
%       a   = vector of link lengths [a1; a2; a3; a4]
%       tol = convergence criterion
%   Output:
%       qf = vector of joint variables (thetas in degrees)
%       iter = number of iterations it took to arrive at the solution qf

% initializing iteration output count
iter = 0;

% Storing link lengths into separate variables for easier inline coding
a1 = a(1);
a2 = a(2);
a3 = a(3);
a4 = a(4);

% ERROR CHECK
b = (P(3) - a1);
c = (a2+a3+a4);
if b^2 > c^2
    iter = 0;
    abs_err = 0;
    qf = 'Geometrically unreachable space.'; % error message
    return
else
    a = sqrt(c^2 - b^2);
    a_des = sqrt(P(1)^2 + P(2)^2);
    if a_des > a
        iter = 0;
        abs_err = 0;
        qf = 'Outside reachable workspace.'; % error message
        return
    end
end

% Formula for function matrix
X = @(q) [cosd(q(1))*(a2*cosd(q(2))+a3*cosd(q(2)+q(3))+a4*cosd(q(2)+q(3)+q(4))); ...
          sind(q(1))*(a2*cosd(q(2))+a3*cosd(q(2)+q(3))+a4*cosd(q(2)+q(3)+q(4))); ...
          a1+a2*sind(q(2))+a3*sind(q(2)+q(3))+a4*sind(q(2)+q(3)+q(4))];
      
% Formula for jacobian matrix
J = @(q) [-sind(q(1))*(a2*cosd(q(2))+a3*cosd(q(2)+q(3))+a4*cosd(q(2)+q(3)+q(4))) -cosd(q(1))*(a2*sind(q(2))+a3*sind(q(2)+q(3))+a4*sind(q(2)+q(3)+q(4))) -cosd(q(1))*(a3*sind(q(2)+q(3))+a4*sind(q(2)+q(3)+q(4))) -a4*cosd(q(1))*sind(q(2)+q(3)+q(4));...
          cosd(q(1))*(a2*cosd(q(2))+a3*cosd(q(2)+q(3))+a4*cosd(q(2)+q(3)+q(4))) -sind(q(1))*(a2*sind(q(2))+a3*sind(q(2)+q(3))+a4*sind(q(2)+q(3)+q(4))) -sind(q(1))*(a3*sind(q(2)+q(3))+a4*sind(q(2)+q(3)+q(4))) -a4*sind(q(1))*sind(q(2)+q(3)+q(4));...
          0 a2*cosd(q(2))+a3*cosd(q(2)+q(3))+a4*cosd(q(2)+q(3)+q(4)) a3*cosd(q(2)+q(3))+a4*cosd(q(2)+q(3)+q(4)) a4*cosd(q(2)+q(3)+q(4))];

% NEWTON's METHOD loop 
qtemp = q_guess;
while true
    qnext = qtemp - pinv(J(qtemp))*(X(qtemp)-P);
    iter = iter+1;
    
    % NORMALIZER: keep the angles equal or less than one full rev (360deg)
    % since the joints are unconstrained
    for i = 1:length(qnext)
        if abs(qnext(i)) > 360
            qnext = qnext./360;
            break;
        end
    end
    
    if norm(qnext-qtemp) < tol
        abs_err = norm(qnext-qtemp);
        qf = qnext;
        break;
    else
        qtemp = qnext;
    end

end

% OPTIMIZER: if absolute value of the angle is greater than 180deg, output
% the opposite direction (to save time by travesing shorter distance)
for i = 1:length(qf)
    if qf(i) < -180
        qf(i) = qf(i) + 360;
    elseif qf(i) > 180
        qf(i) = qf(i) - 360;
    end
end

