clc
format short

% desired endpoint position in 3D [x y z]
P = [1.5; -1; 2.5];

% column vector of initial guess [theta1; theta2; theta3; theta4]
% in degrees
q_guess = [-30; 0; -30; 60];

% link lengths [a1 a2 a3 a4]
a = [2 1 1 0.5];

% storing link lengths into separate variables for easier inline coding
a1 = a(1);
a2 = a(2);
a3 = a(3);
a4 = a(4);

% convergence criterion
tol = 10^-6;

% Inverse Kinematics figure titles
fig_title = {'Inverse Kinematics Using Newton''s Method', 'Inverse Kinematics Using Geometric Approach'};

for j = 1:2
    disp('===============================================')
    disp(newline)
    disp(strcat(fig_title{j},':'))
    disp(newline)
    % Inverse Kinematics & runtime measurement of the numerical method
    if j == 1
        tic
        [qf, iter_count, abs_err] = InvKin_Newton(P,q_guess,a,tol);
        toc
    else
        tic
        qf = InvKin_Geometric(P,a);
        toc
    end
    
    % Error Handling
    % if qf is numeric, plot the output
    % else, output the error message
    if isnumeric(qf)        
        qf
        if j == 1
            iter_count
            abs_err
        end
        
        % defining each robotic arm's link endpoints
        origin = [0 0 0];
        link1 = [0 0 a1];
        link2 = [a2*cosd(qf(1))*cosd(qf(2)) a2*sind(qf(1))*cosd(qf(2)) ...
            a2*sind(qf(2))+a1];
        link3 = [cosd(qf(1))*(a2*cosd(qf(2))+a3*cosd(qf(2)+qf(3))) ...
            sind(qf(1))*(a2*cosd(qf(2))+a3*cosd(qf(2)+qf(3))) ...
            a1+a2*sind(qf(2))+a3*sind(qf(2)+qf(3))];
        link4 = [cosd(qf(1))*(a2*cosd(qf(2))+a3*cosd(qf(2)+qf(3))+a4*cosd(qf(2)+qf(3)+qf(4))) ...
            sind(qf(1))*(a2*cosd(qf(2))+a3*cosd(qf(2)+qf(3))+a4*cosd(qf(2)+qf(3)+qf(4))) ...
            a1+a2*sind(qf(2))+a3*sind(qf(2)+qf(3))+a4*sind(qf(2)+qf(3)+qf(4))];
        
        % storing the endpoints into one array
        arm = {origin link1 link2 link3 link4};
        
        figure(j)
        % plotting the robotic arm
        subplot(2,2,1)
        for i = 2:length(arm)
            if i == length(arm)
                plot3([arm{i-1}(1) arm{i}(1)],[arm{i-1}(2) arm{i}(2)], ...
                    [arm{i-1}(3) arm{i}(3)], '-k', 'LineWidth', 5)
                hold on
                plot3(arm{i}(1), arm{i}(2), arm{i}(3), 'pr', 'Markersize', 25, 'MarkerFaceColor', 'red')
                hold on
            else
                plot3([arm{i-1}(1) arm{i}(1)],[arm{i-1}(2) arm{i}(2)], ...
                    [arm{i-1}(3) arm{i}(3)], '-ok', 'LineWidth', 5, 'MarkerSize', 12, 'MarkerFaceColor', 'blue')
                hold on
            end
            
        end
        title('Isometric')
        hold off
        grid on
        xlabel('x')
        ylabel('y')
        zlabel('z')
        xlim([-2 2])
        ylim([-2 2])
        zlim([0 4])
        
        subplot(2,2,2)
        for i = 2:length(arm)
            if i == length(arm)
                plot3([arm{i-1}(1) arm{i}(1)],[arm{i-1}(2) arm{i}(2)], ...
                    [arm{i-1}(3) arm{i}(3)], '-k', 'LineWidth', 5)
                hold on
                plot3(arm{i}(1), arm{i}(2), arm{i}(3), 'pr', 'Markersize', 25, 'MarkerFaceColor', 'red')
                hold on
            else
                plot3([arm{i-1}(1) arm{i}(1)],[arm{i-1}(2) arm{i}(2)], ...
                    [arm{i-1}(3) arm{i}(3)], '-ok', 'LineWidth', 5, 'MarkerSize', 12, 'MarkerFaceColor', 'blue')
                hold on
            end
            
        end
        title('XY Plane')
        hold off
        grid on
        xlabel('x')
        ylabel('y')
        zlabel('z')
        xlim([-2 2])
        ylim([-2 2])
        zlim([0 4])
        view(0,90)
        
        subplot(2,2,3)
        for i = 2:length(arm)
            if i == length(arm)
                plot3([arm{i-1}(1) arm{i}(1)],[arm{i-1}(2) arm{i}(2)], ...
                    [arm{i-1}(3) arm{i}(3)], '-k', 'LineWidth', 5)
                hold on
                plot3(arm{i}(1), arm{i}(2), arm{i}(3), 'pr', 'Markersize', 25, 'MarkerFaceColor', 'red')
                hold on
            else
                plot3([arm{i-1}(1) arm{i}(1)],[arm{i-1}(2) arm{i}(2)], ...
                    [arm{i-1}(3) arm{i}(3)], '-ok', 'LineWidth', 5, 'MarkerSize', 12, 'MarkerFaceColor', 'blue')
                hold on
            end
            
        end
        title('YZ Plane')
        hold off
        grid on
        xlabel('x')
        ylabel('y')
        zlabel('z')
        xlim([-2 2])
        ylim([-2 2])
        zlim([0 4])
        view(-90,0)
        
        subplot(2,2,4)
        for i = 2:length(arm)
            if i == length(arm)
                plot3([arm{i-1}(1) arm{i}(1)],[arm{i-1}(2) arm{i}(2)], ...
                    [arm{i-1}(3) arm{i}(3)], '-k', 'LineWidth', 5)
                hold on
                plot3(arm{i}(1), arm{i}(2), arm{i}(3), 'pr', 'Markersize', 25, 'MarkerFaceColor', 'red')
                hold on
            else
                plot3([arm{i-1}(1) arm{i}(1)],[arm{i-1}(2) arm{i}(2)], ...
                    [arm{i-1}(3) arm{i}(3)], '-ok', 'LineWidth', 5, 'MarkerSize', 12, 'MarkerFaceColor', 'blue')
                hold on
            end
            
        end
        title('XZ Plane')
        hold off
        grid on
        xlabel('x')
        ylabel('y')
        zlabel('z')
        xlim([-2 2])
        ylim([-2 2])
        zlim([0 4])
        view(0,0)
        sgtitle(fig_title{j})
        
    else
        Error = qf
    end
    
end
