function qf = InvKin_Geometric(P, a)
%INVKIN_GEOMETRIC Inverse Kinematics of 4-DoF 4-Revolute Robotic Arm
%   Computes for the configuration of the revolute joints given the final 
%   position of the arm's end point via geometric approach.
%   Constraints: theta4 negates the total angle formed by theta2 and theta
%   3 to position the last link in parallel to the base x-axis.
%   Input:
%       P   = vector containing the coordinates [x y z] of the arm's
%            desired end-point position
%       a   = vector of link lengths [a1; a2; a3; a4]
%   Output:
%       qf = vector of joint variables (thetas in degrees)

% Storing link lengths into separate variables for easier inline coding
a1 = a(1);
a2 = a(2);
a3 = a(3);
a4 = a(4);

% Storing endpoint positions into separate variables for easier coding
xe = P(1);
ye = P(2);
ze = P(3);

% ERROR CHECK
b = (P(3) - a1);
c = (a2+a3+a4);
if b^2 > c^2
    qf = 'Geometrically unreachable space.'; % error message
    return
else
    a = sqrt(c^2 - b^2);
    a_des = sqrt(P(1)^2 + P(2)^2);
    if a_des > a
        qf = 'Outside reachable workspace.'; % error message
        return
    end
end

% solving for theta1
theta1 = atan2(ye,xe);

% solving for theta3
r = sqrt(xe^2 + ye^2);
r2 = r - a4;
z2 = ze - a1;
h = sqrt(r2^2 + z2^2);
beta = acos((a2^2+a3^2-h^2)/(2*a2*a3));
theta3 = -(pi - beta);

% solving for theta2
gamma = atan2(z2,r2);
alpha = acos((h^2+a2^2-a3^2)/(2*a2*h));
theta2 = alpha + gamma;

% solving for theta4
theta4 = -(theta2 + theta3);

qf = [theta1; theta2; theta3; theta4].*180/pi;